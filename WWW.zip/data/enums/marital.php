<?php
global $em_maritals;
$em_maritals = array();
$em_maritals['1'] = 'δ��';
$em_maritals['2'] = '�ѻ�';
$em_maritals['3'] = '����';
$em_maritals['4'] = 'ɥż';
?>